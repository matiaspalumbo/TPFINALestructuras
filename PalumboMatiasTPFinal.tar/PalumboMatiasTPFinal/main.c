#include "interprete.h"

/* main se encarga de ejecutar el intérprete. */

int main() {
  interface();
  return 0;
}